module.exports = {
  purge: [],
  theme: {
    extend: {
      colors:{
        ...colors.blue,
        "100":"#9cdbdd"
      }
    },
  },
  variants: {},
  plugins: [],
}
